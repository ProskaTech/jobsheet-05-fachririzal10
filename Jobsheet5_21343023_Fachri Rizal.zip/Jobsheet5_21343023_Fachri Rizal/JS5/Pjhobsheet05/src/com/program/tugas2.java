package com.program;

import javax.swing.JOptionPane;

// Created by 21343023_Fachri Rizal
public class tugas2 {
    public static void main(String[] args) {
        
        String kata1 = JOptionPane.showInputDialog("Enter Word 1 : ");
        String kata2 = JOptionPane.showInputDialog("Enter Word 2 : ");


        JOptionPane.showMessageDialog(null,kata1+ " and "+kata2);
    }
}
